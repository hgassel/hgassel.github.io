To run, type `python -m SimpleHTTPServer 8888` from the command line and browse to `localhost:8888`. You can also use the application [MAMP](https://www.mamp.info/en/) if you prefer a GUI.
